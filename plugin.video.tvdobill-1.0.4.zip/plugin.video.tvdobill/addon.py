import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import urllib.request
import re
import os

addon = xbmcaddon.Addon()
ADDON_HANDLE = int(sys.argv[1])
ADDON_PATH = addon.getAddonInfo('path')
ICON = os.path.join(ADDON_PATH, 'icon.png')

M3U_URL = "https://raw.githubusercontent.com/listadobill/tv/main/zteste.m3u"

def get_m3u_channels(url):
    channels = []
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'Kodi'})
        data = urllib.request.urlopen(req, timeout=15).read().decode('utf-8', errors='ignore')

        name = None
        logo = None

        for line in data.splitlines():
            line = line.strip()

            if line.startswith("#EXTINF"):
                name_match = re.search(r',(.+)', line)
                logo_match = re.search(r'tvg-logo="([^"]+)"', line)

                name = name_match.group(1) if name_match else "Canal"
                logo = logo_match.group(1) if logo_match else ICON

            elif line.startswith("http"):
                channels.append((name, line, logo))
                name = None
                logo = None

    except Exception as e:
        xbmc.log(f"[TVdoBill] Erro M3U: {e}", xbmc.LOGERROR)

    return channels

def list_channels():
    for name, url, logo in get_m3u_channels(M3U_URL):
        li = xbmcgui.ListItem(label=name)
        li.setProperty("IsPlayable", "true")
        li.setArt({"icon": logo, "thumb": logo})
        li.setPath(url)

        xbmcplugin.addDirectoryItem(
            handle=ADDON_HANDLE,
            url=url,
            listitem=li,
            isFolder=False
        )

    xbmcplugin.endOfDirectory(ADDON_HANDLE)

if __name__ == "__main__":
    list_channels()
