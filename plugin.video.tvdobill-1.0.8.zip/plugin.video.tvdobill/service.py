import xbmc
import time
import xbmcaddon

class IPTVReconnectPlayer(xbmc.Player):
    def __init__(self):
        super().__init__()
        self.last_url = None
        self.addon = xbmcaddon.Addon()

    def onAVStarted(self):
        self.last_url = self.getPlayingFile()
        xbmc.log(f"[TVdoBill] Tocando: {self.last_url}", xbmc.LOGINFO)

    def onPlayBackEnded(self):
        self.reconnect()

    def onPlayBackStopped(self):
        # Na lógica original, ele reconectava aqui também. 
        # Vou manter, mas com uma pequena verificação para não ser irritante se o usuário quiser parar.
        self.reconnect()

    def onPlayBackError(self):
        self.reconnect()

    def reconnect(self):
        # Verifica se a reconexão está habilitada nas configurações
        reconnect_enabled = self.addon.getSettingBool('reconnect_enabled')
        
        if reconnect_enabled and self.last_url:
            xbmc.log("[TVdoBill] Stream caiu ou parou, tentando reconectar...", xbmc.LOGWARNING)
            time.sleep(2)
            # Tenta reproduzir novamente
            self.play(self.last_url)

if __name__ == "__main__":
    player = IPTVReconnectPlayer()
    monitor = xbmc.Monitor()
    xbmc.log("[TVdoBill] Serviço de monitoramento iniciado.", xbmc.LOGINFO)
    
    while not monitor.abortRequested():
        if monitor.waitForAbort(1):
            break
